// app.js
require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const { Low } = require("lowdb");
const { JSONFile } = require("lowdb/node");
const { nanoid } = require("nanoid");

const app = express();
app.use(bodyParser.json());

// Database setup
const adapter = new JSONFile(process.env.DB_FILE || "db.json");
const db = new Low(adapter, { pools: [] });

async function initDB() {
  await db.read();
  db.data ||= { pools: [] };
  await db.write();
}
initDB();

// Default route
app.get("/", (req, res) => {
  res.send("💰 Welcome to the Financial Pool System! Use /pools to manage pools.");
});

// View all pools
app.get("/pools", async (req, res) => {
  await db.read();
  res.json(db.data.pools);
});

// Create a new pool
app.post("/pools", async (req, res) => {
  const { name, amount } = req.body;

  if (!name || !amount) {
    return res.status(400).json({ error: "Name and amount are required" });
  }

  const newPool = { id: nanoid(), name, amount: parseFloat(amount) };
  db.data.pools.push(newPool);
  await db.write();

  res.status(201).json({ message: "Pool created successfully!", pool: newPool });
});

// Server listen
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`🚀 Financial Pool server running on port ${PORT}`);
});
