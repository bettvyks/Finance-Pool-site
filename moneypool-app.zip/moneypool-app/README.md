# 💰 Money Pool App

A financial pool system built with Node.js, Express, and LowDB.

## 🚀 Run locally
```bash
npm install
npm run dev
```
Visit [http://localhost:4000](http://localhost:4000).

## 🌐 Deploying on Render
- Push this repo to GitHub.
- Create a new **Web Service** on [Render](https://render.com).
- Build Command: `npm install`
- Start Command: `npm start`
- Add environment variables:
  - `NODE_ENV=production`
  - `DB_FILE=db.json`
